create definer = root@localhost trigger 预定即订单触发器_update
    after update
    on booking
    for each row
begin
update pay
set pay.price=new.price,
pay.pay_date=now()
where pay.c_id=old.c_id;
end;

