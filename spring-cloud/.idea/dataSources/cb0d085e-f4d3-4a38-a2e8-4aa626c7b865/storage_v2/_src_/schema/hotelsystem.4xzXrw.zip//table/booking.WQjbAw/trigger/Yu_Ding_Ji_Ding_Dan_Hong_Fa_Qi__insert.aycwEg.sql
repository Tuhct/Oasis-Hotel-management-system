create definer = root@localhost trigger 预定即订单触发器_insert
    after insert
    on booking
    for each row
begin
insert into pay(c_id,price,pay_date)values(new.c_id,new.price,now());
end;

