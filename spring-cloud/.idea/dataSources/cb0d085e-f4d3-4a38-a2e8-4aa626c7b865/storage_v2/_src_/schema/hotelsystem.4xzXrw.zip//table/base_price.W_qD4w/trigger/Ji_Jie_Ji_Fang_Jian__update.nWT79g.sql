create definer = root@localhost trigger 基价即房间_update
    after update
    on base_price
    for each row
begin
update room
set room.price=new.price
where room.room_id=old.room_id;
end;

