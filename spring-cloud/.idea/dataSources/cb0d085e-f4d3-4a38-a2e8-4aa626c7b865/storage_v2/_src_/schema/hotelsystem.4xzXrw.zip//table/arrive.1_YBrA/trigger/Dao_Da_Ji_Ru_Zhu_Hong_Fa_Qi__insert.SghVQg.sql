create definer = root@localhost trigger 到达即入住触发器_insert
    after insert
    on arrive
    for each row
begin
insert into day_in values(new.room_id,new.client_name,new.depart);
end;

