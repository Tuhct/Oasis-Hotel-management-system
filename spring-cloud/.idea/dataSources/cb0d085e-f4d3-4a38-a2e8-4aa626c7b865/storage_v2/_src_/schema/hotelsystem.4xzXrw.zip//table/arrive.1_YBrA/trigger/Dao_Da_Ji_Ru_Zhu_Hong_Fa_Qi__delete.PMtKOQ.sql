create definer = root@localhost trigger 到达即入住触发器_delete
    after delete
    on arrive
    for each row
begin
delete from day_in where
room_id=old.room_id;
end;

